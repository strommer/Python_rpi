# original had same problems as the game of life:
#   used graph and CanvasFrame, which aren't recognized

from graphics import *
import random

BLOCK_SIZE = 30
BOARD_WIDTH = 10
BOARD_HEIGHT = 20

############################################################
# BLOCK CLASS
############################################################

class Block(Rectangle):
    ''' Block class:
        Implement a block for a tetris piece
        Attributes: x - type: int
                    y - type: int
        specify the position on the tetris board
        in terms of the square grid
    '''

    OUTLINE_WIDTH = 3

    def __init__(self, pos, color):
        self.x = pos.x
        self.y = pos.y
        
        p1 = Point(pos.x*BLOCK_SIZE + Block.OUTLINE_WIDTH,
                   pos.y*BLOCK_SIZE + Block.OUTLINE_WIDTH)
        p2 = Point(p1.x + BLOCK_SIZE, p1.y + BLOCK_SIZE)

        Rectangle.__init__(self, p1, p2)
        self.setWidth(Block.OUTLINE_WIDTH)
        self.setFill(color)

    def can_move(self, board, dx, dy):
        ''' Parameters: dx - type: int
                        dy - type: int

            Return value: type: bool
                        
            checks if the block can move dx squares in the x direction
            and dy squares in the y direction
            Returns True if it can, and False otherwise
            HINT: use the can_move method on the Board object
        '''
        return board.can_move(self.x+dx,self.y+dy)
    
    def move(self, dx, dy):
        ''' Parameters: dx - type: int
                        dy - type: int
                        
            moves the block dx squares in the x direction
            and dy squares in the y direction
        '''

        self.x += dx
        self.y += dy

        Rectangle.move(self, dx*BLOCK_SIZE, dy*BLOCK_SIZE)

############################################################
# SHAPE CLASS
############################################################

class Shape():
    ''' Shape class:
        Base class for all the tetris shapes
        Attributes: blocks - type: list - the list of blocks making up the shape
                    rotation_dir - type: int - the current rotation direction of the shape
                    shift_rotation_dir - type: Boolean - whether or not the shape rotates
    '''

    def __init__(self, coords, color):
        self.blocks = []
        self.rotation_dir = 1
        ### A boolean to indicate if a shape shifts rotation direction or not.
        ### Defaults to false since only 3 shapes shift rotation directions (I, S and Z)
        self.shift_rotation_dir = False
        
        for pos in coords:
            self.blocks.append(Block(pos, color))



    def get_blocks(self):
        '''returns the list of blocks
        '''
        return self.blocks

    def draw(self, win):
        ''' Parameter: win - type: CanvasFrame

            Draws the shape:
            i.e. draws each block
        ''' 
        for block in self.blocks:
            block.draw(win)

    def move(self, dx, dy):
        ''' Parameters: dx - type: int
                        dy - type: int

            moves the shape dx squares in the x direction
            and dy squares in the y direction, i.e.
            moves each of the blocks
        '''
        for block in self.blocks:
            block.move(dx, dy)

    def can_move(self, board, dx, dy):
        ''' Parameters: dx - type: int
                        dy - type: int

            Return value: type: bool
                        
            checks if the shape can move dx squares in the x direction
            and dy squares in the y direction, i.e.
            check if each of the blocks can move
            Returns True if all of them can, and False otherwise
           
        '''

        for block in self.blocks:
            if not block.can_move(board,dx,dy):
                return False
        return True
                    
    def get_rotation_dir(self):
        ''' Return value: type: int
        
            returns the current rotation direction
        '''
        return self.rotation_dir

    def can_rotate(self, board):
        ''' Parameters: board - type: Board object
            Return value: type : bool
            
            Checks if the shape can be rotated.
            
            1. Get the rotation direction using the get_rotation_dir method
            2. Compute the position of each block after rotation and check if
            the new position is valid
            3. If any of the blocks cannot be moved to their new position,
            return False
                        
            otherwise all is good, return True
        '''
        
        rot_dir = self.get_rotation_dir()
        center = self.center_block
        self.dx = []
        self.dy = []
        for block in self.blocks:
            # find new position for each block
            # x&y are distances from center of shape
            x = block.x - center.x
            y = block.y - center.y
##            # from pdf:
##            x2 = center.x + rot_dir * y
##            y2 = center.y - rot_dir * x
            # change to rotate CW, x2&y2 are new distances from center of shape
            x2 = - rot_dir * y
            y2 = rot_dir * x
            # amount to move in x&y
            dx = x2-x
            dy = y2-y
            # keep track of movement for def:rotate
            self.dx.append(dx)
            self.dy.append(dy)
##            print(x,y,' to ',x2,y2,' delta ',dx,dy)
            # check whether new pos ok for each block
            if not block.can_move(board,dx,dy):
                return False
        # shape ok to move
        return True
        

    def rotate(self, board):
        ''' Parameters: board - type: Board object

            rotates the shape:
            1. Get the rotation direction using the get_rotation_dir method
            2. Compute the position of each block after rotation
            3. Move the block to the new position
            
        '''    

        rot_dir = self.get_rotation_dir()
        
        center = self.center_block
        k = 0
        for block in self.blocks:
            # move block amount determined in self.can_rotate
            block.move(self.dx[k], self.dy[k])
            k += 1

        ### This should be at the END of your rotate code. 
        ### DO NOT touch it. Default behavior is that a piece will only shift
        ### rotation direciton after a successful rotation. This ensures that 
        ### pieces which switch rotations definitely remain within their 
        ### accepted rotation positions.
        if self.shift_rotation_dir:
            self.rotation_dir *= -1

        

############################################################
# ALL SHAPE CLASSES
############################################################

 
class I_shape(Shape):
    def __init__(self, center):
        coords = [Point(center.x - 2, center.y),
                  Point(center.x - 1, center.y),
                  Point(center.x    , center.y),
                  Point(center.x + 1, center.y)]
        Shape.__init__(self, coords, 'blue')
        self.shift_rotation_dir = True
        self.center_block = self.blocks[2]

class J_shape(Shape):
    def __init__(self, center):
        coords = [Point(center.x - 1, center.y),
                  Point(center.x    , center.y),
                  Point(center.x + 1, center.y),
                  Point(center.x + 1, center.y + 1)]
        Shape.__init__(self, coords, 'orange')        
        self.center_block = self.blocks[1]

class L_shape(Shape):
    def __init__(self, center):
        coords = [Point(center.x - 1, center.y),
                  Point(center.x    , center.y),
                  Point(center.x + 1, center.y),
                  Point(center.x - 1, center.y + 1)]
        Shape.__init__(self, coords, 'cyan')        
        self.center_block = self.blocks[1]


class O_shape(Shape):
    def __init__(self, center):
        coords = [Point(center.x    , center.y),
                  Point(center.x - 1, center.y),
                  Point(center.x   , center.y + 1),
                  Point(center.x - 1, center.y + 1)]
        Shape.__init__(self, coords, 'red')
        self.center_block = self.blocks[0]

    def rotate(self, board):
        # Override Shape's rotate method since O_Shape does not rotate
        return 

class S_shape(Shape):
    def __init__(self, center):
        coords = [Point(center.x    , center.y),
                  Point(center.x    , center.y + 1),
                  Point(center.x + 1, center.y),
                  Point(center.x - 1, center.y + 1)]
        Shape.__init__(self, coords, 'green')
        self.center_block = self.blocks[0]
        self.shift_rotation_dir = True
        self.rotation_dir = -1


class T_shape(Shape):
    def __init__(self, center):
        coords = [Point(center.x - 1, center.y),
                  Point(center.x    , center.y),
                  Point(center.x + 1, center.y),
                  Point(center.x    , center.y + 1)]
        Shape.__init__(self, coords, 'yellow')
        self.center_block = self.blocks[1]


class Z_shape(Shape):
    def __init__(self, center):
        coords = [Point(center.x - 1, center.y),
                  Point(center.x    , center.y), 
                  Point(center.x    , center.y + 1),
                  Point(center.x + 1, center.y + 1)]
        Shape.__init__(self, coords, 'magenta')
        self.center_block = self.blocks[1]
        self.shift_rotation_dir = True
        self.rotation_dir = -1      



############################################################
# BOARD CLASS
############################################################

class Board():
    ''' Board class: it represents the Tetris board

        Attributes: width - type:int - width of the board in squares
                    height - type:int - height of the board in squares
                    canvas - type:CanvasFrame - where the pieces will be drawn
                    grid - type:Dictionary - keeps track of the current state of
                    the board; stores the blocks for a given position
    '''
        
    def __init__(self, win):
        self.canvas = win
        self.canvas.setBackground('light gray')

        # create an empty dictionary
        # currently we have no shapes on the board
        self.grid = {}

    def draw_shape(self, shape):
        ''' Parameters: shape - type: Shape
            Return value: type: bool

            draws the shape on the board if there is space for it
            and returns True, otherwise it returns False
        '''
        if shape.can_move(self, 0, 0):
            shape.draw(self.canvas)
            return True
        return False

    def can_move(self, x, y):
        ''' Parameters: x - type:int
                        y - type:int
            Return value: type: bool

            1. check if it is ok to move to square x,y
            if the position is outside of the board boundaries, can't move there
            return False

            2. if there is already a block at that postion, can't move there
            return False

            3. otherwise return True            
        '''

        if x in range(BOARD_WIDTH) and \
            y in range(BOARD_HEIGHT) and \
            (x,y) not in self.grid:
                    return True
        return False

    def add_shape(self, shape):
        ''' Parameter: shape - type:Shape
            
            add a shape to the grid, i.e.
            add each block to the grid using its
            (x, y) coordinates as a dictionary key

            Hint: use the get_blocks method on Shape to
            get the list of blocks
            
        '''

        # get list of blocks
        blocks = shape.get_blocks()
        for block in blocks:
            # add each block to dict
            self.grid[block.x,block.y] = block
        


    def delete_row(self, y):
        ''' Parameters: y - type:int

            remove all the blocks in row y
            to remove a block you must remove it from the grid
            and erase it from the screen.
            If you dont remember how to erase a graphics object
            from the screen, take a look at the Graphics Library
            handout
            
        '''
        # go through all blocks in row - check whether in grid
        for x in range(BOARD_WIDTH):
            block = self.grid[x,y]
            # delete block from grid
            del self.grid[x,y]
            # undraw block
            block.undraw()
        
    
    def is_row_complete(self, y):        
        ''' Parameter: y - type: int
            Return value: type: bool

            for each block in row y
            check if there is a block in the grid (use the in operator) 
            if there is one square that is not occupied, return False
            otherwise return True
            
        '''
        
        # go through all blocks in row - check whether in grid
        for x in range(BOARD_WIDTH):
            if (x,y) not in self.grid:
                # row not complete
                return False
        return True
    
    def move_down_rows(self, y_start):
        ''' Parameters: y_start - type:int                        

            for each row from y_start to the top
                for each column
                    check if there is a block in the grid
                    if there is, remove it from the grid
                    and move the block object down on the screen
                    and then place it back in the grid in the new position

        '''
        # can't loop thru dict b/c get 'change size' error
        
        for x in range(BOARD_WIDTH):
            for y in reversed(range(y_start+1)):
                if (x,y) in self.grid:
                    block = self.grid[x,y]
                    del self.grid[x,y]    # remove from grid
                    block.move(0,1) # move down 1 square
                    self.grid[x,y+1] = block  # add new pos to grid 
                       
        
    
    def remove_complete_rows(self):
        ''' removes all the complete rows
            1. for each row, y, 
            2. check if the row is complete
                if it is,
                    delete the row
                    move all rows down starting at row y - 1

        '''
        
        for y in range(BOARD_HEIGHT):
            # check each row to see if complete
            if self.is_row_complete(y):  # need to remove row and move down
                self.delete_row(y)
                self.move_down_rows(y-1)

    def game_over(self):
        ''' display "Game Over !!!" message in the center of the board
            HINT: use the Text class from the graphics library
        '''
        # draw white oval so can read text
        oval = Oval(Point(0,1.2*BOARD_HEIGHT/2*BLOCK_SIZE), \
                    Point(BOARD_WIDTH*(BLOCK_SIZE),.8*BOARD_HEIGHT/2*BLOCK_SIZE))
        oval.setFill('white')
        oval.draw(self.canvas)
        # draw text displaying 'Game Over!!!'
        text = Text(Point(BOARD_WIDTH/2*(BLOCK_SIZE),BOARD_HEIGHT/2*BLOCK_SIZE),'Game Over!!!')
        text.setSize(32)
        text.setStyle('bold')
        text.draw(self.canvas)


############################################################
# TETRIS CLASS
############################################################

# Ryan, moved variables here, otherwise wouldn't work...
SHAPES = [I_shape, J_shape, L_shape, O_shape, S_shape, T_shape, Z_shape]
DIRECTION = {'Left':(-1, 0), 'Right':(1, 0), 'Down':(0, 1)}

class Tetris():
    ''' Tetris class: Controls the game play
        Attributes:
            SHAPES - type: list (list of Shape classes)
            DIRECTION - type: dictionary - converts string direction to (dx, dy)
            BOARD_WIDTH - type:int - the width of the board
            BOARD_HEIGHT - type:int - the height of the board
            board - type:Board - the tetris board
            win - type:Window - the window for the tetris game
            delay - type:int - the speed in milliseconds for moving the shapes
            current_shapes - type: Shape - the current moving shape on the board
    '''

    # Ryan - how did you get this to work? I just moved to top
    #SHAPES = [I_shape, J_shape, L_shape, O_shape, S_shape, T_shape, Z_shape]
    #DIRECTION = {'Left':(-1, 0), 'Right':(1, 0), 'Down':(0, 1)}
    
    def __init__(self, win):
        self.board = Board(win)
        self.win = win
        self.delay = 1000 #ms

        # sets up the keyboard events
        # when a key is called the method key_pressed will be called
        self.win.bind_all('<Key>', self.key_pressed)

        # set the current shape to a random new shape
        self.current_shape = self.create_new_shape()
        
        # Draw the current_shape on the board (take a look at the
        # draw_shape method in the Board class)
        self.board.draw_shape(self.current_shape)

        # For Step 9:  animate the shape!
        self.animate_shape()


    def create_new_shape(self):
        ''' Return value: type: Shape
            
            Create a random new shape that is centered
             at y = 0 and x = int(self.BOARD_WIDTH/2)
            return the shape
        '''

        # pick one of the 7 shapes at random
        n = random.randint(0,6)
        shape = SHAPES[n](Point(round(BOARD_WIDTH/2),0))
        return shape
    
    def animate_shape(self):
        ''' animate the shape - move down at equal intervals
            specified by the delay attribute
        '''
        
        self.do_move('Down')
        self.win.after(self.delay, self.animate_shape)
    
    def do_move(self, direction):
        ''' Parameters: direction - type: string
            Return value: type: bool

            Move the current shape in the direction specified by the parameter:
            First check if the shape can move. If it can, move it and return True
            Otherwise if the direction we tried to move was 'Down',
            1. add the current shape to the board
            2. remove the completed rows if any 
            3. create a new random shape and set current_shape attribute
            4. If the shape cannot be drawn on the board, display a
               game over message

            return False

        '''
        
##        if direction in DIRECTION:  # left, right, or down
        (dx,dy) = DIRECTION[direction]  # get dx & dy from dict
        if self.current_shape.can_move(self.board,dx,dy):   # OK to move
            self.current_shape.move(dx,dy)
            return True
        else:   # not OK to move
            if direction == 'Down':
                # shape in final position, need to add blocks to grid
                # add shape to grid
                self.board.add_shape(self.current_shape)
                # remove complete rows
                self.board.remove_complete_rows()
                # make new shape at top
                self.current_shape = self.create_new_shape()
                # draw new shape
                ret = self.board.draw_shape(self.current_shape)
                if ret == False:
                    self.game_over()
            return False
            

    def do_rotate(self):
        ''' Checks if the current_shape can be rotated and
            rotates if it can
        '''
        
        if self.current_shape.can_rotate(self.board) == True:
            self.current_shape.rotate(self.board)

    
    def key_pressed(self, event):
        ''' this function is called when a key is pressed on the keyboard
            it currenly just prints the value of the key

            Modify the function so that if the user presses the arrow keys
            'Left', 'Right' or 'Down', the current_shape will move in
            the appropriate direction

            if the user presses the space bar 'space', the shape will move
            down until it can no longer move and is added to the board

            if the user presses the 'Up' arrow key ,
                the shape should rotate.

        '''
            
        key = event.keysym
##        # if program key, just pass to do_move
##        if key in ['Up','Down','Right','Left','Space']:
##            self.do_move(key)
        if key in DIRECTION:  # left, right, or down
            self.do_move(key)
        elif key == 'space':
            # keep moving down by 1 block until can't move anymore
            dx = 0
            dy = 1
            while self.current_shape.can_move(self.board,dx,dy):   # OK to move down
                self.current_shape.move(dx,dy)  # move down
            self.do_move('Down')    # call do_move to add shape to grid, make new shape...
        elif key == 'Up':
            self.do_rotate()
        #print(key)
       
################################################################
# Start the game
################################################################

win = GraphWin("Tetris",BOARD_WIDTH * BLOCK_SIZE,
                        BOARD_HEIGHT * BLOCK_SIZE)
game = Tetris(win)
win.mainloop()
